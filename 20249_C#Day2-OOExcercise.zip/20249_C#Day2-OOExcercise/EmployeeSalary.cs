using System;
using System.Collections.Generic;
using System.Text;

namespace DayOne
{
    class EmployeeSalary
    {
        public int empId { get; set; }
        public string name { get; set; }
        protected double basicsal { get; set; }
        double hr_all { get; set; }
        double trav_al { get; set; }
        static int tax_per { get; set; }


        public EmployeeSalary(int eid,string ename,double sal,double hr,double trav,int per)
        {
            this.empId = eid;
            this.name = ename;
            this.basicsal = sal;
            this.hr_all = hr;
            this.trav_al = trav;
        }

        static EmployeeSalary()
        {
            tax_per = 20;
        }

        public double salCalc()
        {
            double totsal = this.basicsal + this.hr_all + this.trav_al;
            totsal = totsal - (totsal * tax_per)/100;
            return totsal;
        }

        public string display()
        {
            return $"{name} with empid {empId} getting a basic salary of {this.basicsal}, hr allowance of {hr_all} and travel allowance of {trav_al} draws a total salary of \n{this.salCalc()}";
        }
    }

    class TestEmployeeSalary
    {
        public static void Main()
        {
            EmployeeSalary e1 = new EmployeeSalary(20249, "Puneeth", 35000d, 4500d, 2000d, 20);
            Console.WriteLine($"The details of emp e1 is:\n{e1.display()}");
        }
        
    }
}