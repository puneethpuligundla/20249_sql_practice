using System;

namespace DayOne
{
    class Circle
    {
        public double radius { get; set; }

        public Circle(int rad)
        {
            this.radius = rad;           
        }
        public double calcDiameter()
        {
            return 2 * this.radius;
        }

        public double calcArea()
        {
            return Math.PI * this.radius * this.radius;
        }

        static void Main(string[] args)
        {
            Circle c = new Circle(5);
            Console.WriteLine($"The diameter for given {c.radius} is {c.calcDiameter()}");
            Console.WriteLine($"The are for given {c.radius} is {c.calcArea()}");
        }
    }
}
