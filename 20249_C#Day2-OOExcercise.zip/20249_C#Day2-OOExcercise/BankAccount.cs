using System;
using System.Collections.Generic;
using System.Text;

namespace DayOne
{
    class BankAccount
    {
        public double bal { get; set; }

        public BankAccount()
        {
            bal = 500d;
        }

        public BankAccount(double balance)
        {
            this.bal = balance;
        }

        public double display()
        {
            return this.bal;
        }

    }

    class TestBankAccount{
        public static void Main()
        {
            BankAccount b1 = new BankAccount(500);
            BankAccount b2 = new BankAccount();
            Console.WriteLine($"bal from parameter constructor {b1.display()}");
            Console.WriteLine($"bal from default constructor {b2.display()}");
        }
    }
}
