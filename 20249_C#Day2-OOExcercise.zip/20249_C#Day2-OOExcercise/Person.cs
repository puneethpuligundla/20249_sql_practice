using System;
using System.Collections.Generic;
using System.Text;

namespace DayOne
{
    class Person
    {
        public string name { get; set; }
        public DateTime DOB { get; set; }
        public string address { get; set; }
        public string mar_stat { get; set; }

        public Person()
        {
            name = "";
            DOB = DateTime.MinValue;
            address = "";
            mar_stat = "";
        }

        public Person(string pname,DateTime bday,string add,string mar_sts)
        {
            this.name = pname;
            this.DOB = bday;
            this.address = add;
            this.mar_stat = mar_sts;
        }

        public int getAge()
        {
            int age = DateTime.Now.Subtract(this.DOB).Days;
            age /= 365;
            return age;
        }

        public bool canMarry()
        {
            if(this.getAge()>18 && (this.mar_stat!="Married" || this.mar_stat!="married"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override string ToString()
        {
            return $"{this.name} lives at, {this.address}, born on {this.DOB}, {this.mar_stat}, is {this.getAge()} old and can marry is {this.canMarry()}";
        }

    }

    class TestPerson
    {
        public static void Main()
        {
            Person p1 = new Person("Fred", new DateTime(1980, 12, 12), "21 Lancaster Road", "Single");
            Console.WriteLine(p1.ToString());
        }
    }
}
