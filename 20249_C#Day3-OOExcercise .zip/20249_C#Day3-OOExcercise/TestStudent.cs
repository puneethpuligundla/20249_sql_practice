using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    class Student
    {
        public int regno { get; set; }
        public string name { get; set; }

        public Student()
        {
            regno =int.MinValue;
            name = "";
        }

        public Student(int rno,string sname)
        {
            this.regno = rno;
            this.name = sname;
        }

        

    }

    class Science : Student
    {
        int mphysics { get; set; }
        int mchem { get; set; }
        int mmath { get; set; }

        public Science(int roll,string ename,int phym,int chem,int mathm) : base(roll, ename)
        {
            this.mphysics = phym;
            this.mchem = chem;
            this.mmath = mathm;
        }

        public string getMarks()
        {
            return $"Name:{this.name} RegNo:{this.regno} Physics marks:{mphysics},Chem Marks:{mchem},Math Marks{mmath}, Avg of 3 Subjects:{this.getAvg()}";
        }

        public int getAvg()
        {
            return (mphysics + mchem + mmath) / 3;
        }
    }

    class Commerce : Student
    {
        int meco { get; set; }
        int macc { get; set; }
        int mbank { get; set; }

        public Commerce(int roll, string ename, int eco, int accm, int bankm) : base(roll, ename)
        {
            this.meco = eco;
            this.macc = accm;
            this.mbank = bankm;
        }

        public string getMarks()
        {
            return $"Name:{this.name} RegNo:{this.regno} Economics marks:{meco},Accounts Marks:{macc},Banking Marks{mbank} Avg of 3 Subjects:{this.getAvg()}";
        }

        public int getAvg()
        {
            return (meco + macc + mbank) / 3;
        }
    }

    class TestStudent
    {
        public static void Main()
        {
            Science s1 = new Science(20249, "Puneeth", 81, 85, 90);
            Console.WriteLine(s1.getMarks());

            Commerce s2 = new Commerce(20298, "Arun", 90, 91, 93);
            Console.WriteLine(s2.getMarks());
        }
    }
}
