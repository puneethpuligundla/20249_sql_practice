using System;

namespace Day2
{
    struct Person
    {
        public string name;
        public char sex;
        public int height;
        public double weight;
    };
    public class TestStructure 
    { 
    
        static void Main(string[] args)
        {
            Person p1;
            

            Console.WriteLine("Enter Person1's name:");
            p1.name = Console.ReadLine();

            Console.WriteLine("Enter Person1's gender:");
            p1.sex = char.Parse(Console.ReadLine());

            Console.WriteLine("Enter Person1's height in cms:");
            p1.height = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Person1's Weight in kilograms:");
            p1.weight = double.Parse(Console.ReadLine());

            Console.WriteLine($"{p1.name} is a {p1.sex} who is {p1.height} cms in height and {p1.weight} kilos in weight");
        }
    }
}
