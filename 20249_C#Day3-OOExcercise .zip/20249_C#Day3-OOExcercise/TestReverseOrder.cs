using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsPractice
{

    class ReverseOrder
    {
        public static void Main()
        {
            Stack<int> s1 = new Stack<int>();
            Console.WriteLine("Enter the total number of elements");
            int N = int.Parse(Console.ReadLine());
            Console.WriteLine($"Enter {N} elements");
            foreach (int i in Enumerable.Range(1, N))
            {
                s1.Push(int.Parse(Console.ReadLine()));
            }
            Console.WriteLine("The values after reversing the order");
            for (int i = 0; i < N; i++)
            {
                Console.WriteLine(s1.Pop());
            }
        }
    }
}
