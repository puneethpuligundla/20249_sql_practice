using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    class Age
    {
        public int age { get; set; }

        public Age()
        {
            age = 0;
        }

        public Age(int num)
        {
            this.age = num;
        }

        public void validDob()
        {
            if (age <= 0)
            {
                throw (new InvalidAgeException("Age Entered is Invalid"));

            }
            else
            {
                Console.WriteLine($"Age is {age}");
            }
        }
    }
    public class InvalidAgeException : Exception
    {
        public InvalidAgeException(string msg) : base(msg)
        {

        }
    }
    public class TestAge
    {
        public static void Main()
        {
            Age a1 = new Age(-2);
            try
            {
                a1.validDob();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.Message}");
            }
        }
    }


}
