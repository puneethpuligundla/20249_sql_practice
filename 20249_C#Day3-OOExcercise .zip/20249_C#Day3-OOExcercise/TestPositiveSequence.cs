using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsPractice
{

    class TestPositiveAssendingOrder
    {
        public static void Main()
        {
            List<int> pos_num = new List<int>();
            Console.WriteLine("Enter the positive numbers");
            while (true)
            {
                string str = Console.ReadLine();
                if (str == string.Empty)
                {
                    break;
                }
                else
                {
                    int num = int.Parse(str);
                    if (num > 0)
                    {
                        pos_num.Add(num);
                    }
                    else
                    {
                        Console.WriteLine("You have entered a non positive integer");
                    }
                }
            }
            pos_num.Sort();
            int count = pos_num.Count;
            foreach (int i in pos_num)
            {
                Console.WriteLine(i);
            }
        }
    }
}
