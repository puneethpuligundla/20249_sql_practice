using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




namespace CollectionsPractice
{
    class TestRemOddSeq
    {
        static void Main(string[] args)
        {
            Dictionary<int, int> d = new Dictionary<int, int>();
            List<int> li = new List<int>();


            Console.WriteLine("Enter Desired I/P");
            while (true)
            {
                string inp = Console.ReadLine();
                if (inp.Equals(""))
                    break;

                int num = int.Parse(inp);

                if (d.ContainsKey(num))
                {
                    d[num] = d[num] + 1;
                }
                else
                {
                    d.Add(num, 1);
                }
            }

            foreach (int i in d.Keys)
            {
                if (d[i] % 2 == 0)
                    li.Add(i);
            }

            Console.WriteLine("values with only even occurances");
            foreach (int i in li)
            {
                Console.WriteLine(i);
            }
        }
    }
}