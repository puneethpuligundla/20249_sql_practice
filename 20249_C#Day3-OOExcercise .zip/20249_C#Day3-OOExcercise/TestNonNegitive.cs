﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsPractice
{
    
class TestNonNegative
    {
        public static void Main()
        {
            List<int> NonNegative = new List<int>();
            Console.WriteLine("Enter the numbers");
            while (true)
            {
                string str = Console.ReadLine();
                if (str == string.Empty)
                {
                    break;
                }
                else
                {
                    int num = int.Parse(str);
                    NonNegative.Add(num);
                }
            }
            Console.WriteLine("The updated list is:");
            int count = NonNegative.Count;
            int c = 0;
            int i = 0;
            while (c < count)
            {

                for (int i=0; i < count; i++)
                {
                    if (NonNegative.ElementAt(i) < 0)
                    {
                        NonNegative.RemoveAt(i);
                        count--;
                        c = i;
                        break;
                    }
                    else
                        continue;
                }
                c++;
            }
            if (NonNegative.ElementAt(0) < 0)
                NonNegative.RemoveAt(0);
            foreach (int num in NonNegative)
            {
                Console.WriteLine(num);
            }
        }
    }
}
