using System;
using System.Collections.Generic;
using System.Linq;

namespace CollectionsPractice
{
    class Program
    {

        private static List<int> ReadIntegers()
        {
            List<int> seq = new List<int>();
            Console.WriteLine("Enter any number of +ve Integers");
            string input = Console.ReadLine();

            while (input != string.Empty)
            {
                int num = -1;
                try
                {
                    num = int.Parse(input);
                    if(num < 0)
                    {
                        Console.WriteLine("Invalid Input, Enter +ve Integers only");
                    }
                    else
                    {
                        seq.Add(num);
                    }
                }catch(OverflowException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch(FormatException)
                {
                    Console.WriteLine("Only +ve integers have to be entered");
                }
                input = Console.ReadLine();
            }
            Console.WriteLine("The added nos are" + string.Join(", ", seq));
            return seq;
        }
        static void Main(string[] args)
        {
            List<int> sequence = ReadIntegers();
            Console.WriteLine($"The sum of the nos in the sequence is {sequence.Sum()}");
            Console.WriteLine($"The avg of the nos in the sequence is {sequence.Average()}");

        }
    }
}
